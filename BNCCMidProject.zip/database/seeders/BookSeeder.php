<?php

namespace Database\Seeders;

use App\Models\Book;
use Carbon\Carbon;
use Database\Factories\BookFactory;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class BookSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        Book::factory(15)->create();
        DB::table('books')->insert([
            'title' => 'The Chemist',
            'author' => 'Stephanie Meyer',
            'pages' => '560',
            'year' => '2018',
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now()
        ]);
    }
}
