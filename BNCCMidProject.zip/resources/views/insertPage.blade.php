@extends('template')

@section('title', 'insert form')

@section('content')
    <div class="d-flex justify-content-center align-items-center min-vh-100 container py-5">
        <div class="card" style="width: 100%; max-width: 30rem;">
            <div class="card-body">
                <h5 class="card-title">Insert Book</h5>
            </div>
            <div class="card-body">

                <form action="" method="" autocomplete="off">
                    @csrf
                    <div class="mb-3">
                        <input type="text" name="title" id="title" placeholder="Book Title" class="form-control">
                    </div>
                    <div class="mb-3">
                        <input type="text" name="author" id="author" placeholder="Author" class="form-control">
                    </div>
                    <div class="mb-3">
                        <input type="number" name="pages" id="pages" placeholder="Number of Pages" class="form-control">
                    </div>
                    <div class="mb-3">
                        <input type="number" name="year" id="year" placeholder="Published Year" class="form-control">
                    </div>
                    <div class="mb-3">
                        <button class="btn btn-primary form-control">Insert</button>
                    </div>
                </form>

                @if($errors->any())
                    <div>class="alert alert-danger" role="alert"</div>
                    {{$message}}
                @endif
            </div>
        </div>
    </div>
@endsection
