@extends('template')

@section('title', 'index')

@section('content')
    <h1>Book Information</h1>

    <form action="{{route('insertPage')}}" method="POST">
        @csrf
        <button type="submit">Insert New Book</button>
    </form>

    <div>
        <table class="table table-hover">
            <thead>
            <tr>
                <th>Title</th>
                <th>Author</th>
                <th>Pages</th>
                <th>Year Published</th>
            </tr>
            </thead>
            <tbody>
            @foreach($books as $book)
                <tr>
                    <td>{{$book->title}}</td>
                    <td>{{$book->author}}</td>
                    <td>{{$book->pages}}</td>
                    <td>{{$book->year}}</td>

                    <form action="{{route('destroy')}}" method="POST">
                        @method('delete')
                        @csrf
                        <td><button class="btn btn-danger" type="submit">Delete</button></td>
                    </form>

                    <form action="" method="POST">
                        {{-- {{route('updatePage')}} --}}
                        @method('patch')
                        @csrf
                        <td><button type="submit">Update</button></td>
                    </form>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
@endsection
