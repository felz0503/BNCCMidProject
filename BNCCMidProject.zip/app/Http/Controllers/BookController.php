<?php

namespace App\Http\Controllers;

use App\Models\Book;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BookController extends Controller
{

    public function viewBooks()
    {
        $books = Book::all();
        return view('/index', compact('books'));
    }

    public function insertPage(){
        return view('insertPage');
    }

    public function create(Request $request){
        $request->validate([
            'title' => 'required|min:5|max:20',
            'author' => 'required|min:5|max:20',
            'pages' => 'required|numeric|min:1',
            'year' => 'required|numeric|min:2000|max:2021'
        ],[
            'title.required' => 'this field can not be empty',
            'author.required' => 'this field can not be empty',
            'pages.required' => 'this field can not be empty',
            'year.required' => 'this field can not be empty',
            'title.min' => 'minimum character is 5',
            'author.min' => 'minimum character is 5',
            'title.max' => 'maximum character is 20',
            'author.max' => 'maximum character is 20',
            'pages.min' => 'minimum page is 1',
            'year.min' => 'published year must be between 2000-2021',
            'year.max' => 'published year must be between 2000-2021',
        ]);

        Book::create([
            'title' => $request->input('title'),
            'author' => $request->input('author'),
            'pages' => $request->input('pages'),
            'year' => $request->input('year')
        ]);

        return redirect('/');
    }

    public function updatePage(){
        return view('updatePage');
    }

    public function update(Book $book, Request $request){

        $request->validate([
            'title' => 'required|min:5|max:20',
            'author' => 'required|min:5|max:20',
            'pages' => 'required|numeric|min:1',
            'year' => 'required|numeric|min:2000|max:2021'
        ],[
            'title.required' => 'this field can not be empty',
            'author.required' => 'this field can not be empty',
            'pages.required' => 'this field can not be empty',
            'year.required' => 'this field can not be empty',
            'title.min' => 'minimum character is 5',
            'author.min' => 'minimum character is 5',
            'title.max' => 'maximum character is 20',
            'author.max' => 'maximum character is 20',
            'pages.min' => 'minimum page is 1',
            'year.min' => 'published year must be between 2000-2021',
            'year.max' => 'published year must be between 2000-2021',
        ]);

        $book->title = $request->input('title');
        $book->author = $request->input('author');
        $book->pages = $request->input('pages');
        $book->year = $request->input('pages');

        $book->save();

        return redirect('/');
    }

    public function destroy(Book $book)
    {
        $book->delete();
        return redirect()->back();
    }
}
