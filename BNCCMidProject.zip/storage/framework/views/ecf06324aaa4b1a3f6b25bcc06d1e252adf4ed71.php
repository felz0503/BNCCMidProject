<?php $__env->startSection('title', 'insert form'); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('create')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="title">Book Title</label>
            <input type="text" class="form-control" name="title" id="title">
        </div>
        <div class="form-group">
            <label for="author">Author</label>
            <input type="text" class="form-control" name="author" id="author">
        </div>
        <div class="form-group">
            <label for="pages">Number of Page</label>
            <input type="number" class="form-control" name="pages" id="pages">
        </div>
        <div class="form-group">
            <label for="title">Year</label>
            <input type="number" class="form-control" name="year" id="year">
        </div>
        <button type="submit" class="btn btn-primary">Insert</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\BNCCMidProject\resources\views//insertPage.blade.php ENDPATH**/ ?>