<?php $__env->startSection('title', 'index'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Book Information</h1>

    <form action="<?php echo e(route('insertPage')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit">Insert New Book</button>
    </form>

    <div>
        <table class="table table-hover">
            <thead>
            <tr>
                <th>Title</th>
                <th>Author</th>
                <th>Pages</th>
                <th>Year Published</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($book->title); ?></td>
                    <td><?php echo e($book->author); ?></td>
                    <td><?php echo e($book->pages); ?></td>
                    <td><?php echo e($book->year); ?></td>

                    <form action="<?php echo e(route('destroy')); ?>" method="POST">
                        <?php echo method_field('delete'); ?>
                        <?php echo csrf_field(); ?>
                        <td><button class="btn btn-danger" type="submit">Delete</button></td>
                    </form>

                    <form action="" method="POST">
                        
                        <?php echo method_field('patch'); ?>
                        <?php echo csrf_field(); ?>
                        <td><button type="submit">Update</button></td>
                    </form>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\BNCCMidProject\resources\views//index.blade.php ENDPATH**/ ?>