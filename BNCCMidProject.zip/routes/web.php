<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [BookController::class, 'viewBooks']);

Route::POST('/insertPage', [BookController::class, 'insertPage'])->name('insertPage');

Route::POST('/create', [BookController::class, 'create'])->name('create');

Route::POST('/updatePage', [BookController::class, 'updatePage'])->name('updatePage');

Route::get('/delete', [BookController::class, 'destroy'])->name('destroy');

// Route::resource('bookController', BookController::class)->names([
//     'destroy' => 'bookController.destroy'
// ]);
